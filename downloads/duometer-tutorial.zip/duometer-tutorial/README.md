This is a demonstration corpus for duometer. See https://github.com/pmandera/duometer for more information.

The corpus contains excerpts from Alice in Wonderland by Lewis Caroll.
